package com.healthtracker.app.ui.screen

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.healthtracker.app.model.User
import com.healthtracker.app.utils.HealthCalculations
import com.healthtracker.app.viewmodel.HealthRecordViewModel

@Composable
fun AnalysisScreen(
    user: User,
    recordViewModel: HealthRecordViewModel,
    modifier: Modifier = Modifier
) {
    val records by recordViewModel.records.collectAsState()
    val latestRecord = records.firstOrNull()
    val analysis = remember(user, latestRecord) {
        HealthCalculations.buildAnalysis(user, latestRecord)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "${user.name} 的健康分析",
            style = MaterialTheme.typography.headlineSmall
        )

        // BMI Card
        AnalysisCard(title = "BMI 指数") {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "%.1f".format(analysis.bmi),
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = analysis.bmiColor
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = analysis.bmiCategory,
                    fontSize = 20.sp,
                    color = analysis.bmiColor,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            Text(
                text = "理想体重范围: %.1f - %.1f kg".format(analysis.idealWeightMin, analysis.idealWeightMax),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.outline
            )
        }

        // Body Fat
        AnalysisCard(title = "体脂率估算") {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = "%.1f%%".format(analysis.bodyFatPercent),
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = analysis.bodyFatCategory,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(bottom = 4.dp)
                )
            }
        }

        // Blood Pressure
        if (latestRecord != null) {
            AnalysisCard(title = "最新血压 (${latestRecord.systolic}/${latestRecord.diastolic} mmHg)") {
                Text(
                    text = analysis.bpCategory,
                    fontSize = 28.sp,
                    fontWeight = FontWeight.Bold,
                    color = analysis.bpColor
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = analysis.bpAdvice,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }

        // BMR
        AnalysisCard(title = "基础代谢率 (BMR)") {
            Text(
                text = "%.0f kcal/天".format(analysis.basalMetabolicRate),
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = "这是你每天静息状态下消耗的热量",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.outline
            )
        }

        // Diet Advice
        AnalysisCard(title = "饮食建议") {
            Text(text = analysis.dietAdvice, style = MaterialTheme.typography.bodyMedium, lineHeight = 22.sp)
        }

        // Exercise Advice
        AnalysisCard(title = "运动建议") {
            Text(text = analysis.exerciseAdvice, style = MaterialTheme.typography.bodyMedium, lineHeight = 22.sp)
        }

        Spacer(modifier = Modifier.height(32.dp))
    }
}

@Composable
fun AnalysisCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
            content()
        }
    }
}
