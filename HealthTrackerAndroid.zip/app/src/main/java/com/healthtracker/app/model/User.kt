package com.healthtracker.app.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val gender: String,  // "男" or "女"
    val age: Int,
    val heightCm: Float,  // 厘米
    val createdAt: Long = System.currentTimeMillis()
)
