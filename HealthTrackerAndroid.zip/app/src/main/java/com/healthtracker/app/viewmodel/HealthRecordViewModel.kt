package com.healthtracker.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.healthtracker.app.data.HealthRecordDao
import com.healthtracker.app.model.HealthRecord
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HealthRecordViewModel(private val recordDao: HealthRecordDao) : ViewModel() {

    private val _records = MutableStateFlow<List<HealthRecord>>(emptyList())
    val records: StateFlow<List<HealthRecord>> = _records.asStateFlow()

    private var collectJob: Job? = null

    fun loadRecords(userId: Long) {
        collectJob?.cancel()
        collectJob = viewModelScope.launch {
            recordDao.getRecordsByUser(userId).collect { list ->
                _records.value = list
            }
        }
    }

    fun addRecord(userId: Long, date: Long, weightKg: Float, systolic: Int, diastolic: Int, heartRate: Int, note: String) {
        viewModelScope.launch {
            recordDao.insert(
                HealthRecord(
                    userId = userId,
                    date = date,
                    weightKg = weightKg,
                    systolic = systolic,
                    diastolic = diastolic,
                    heartRate = heartRate,
                    note = note
                )
            )
        }
    }

    fun deleteRecord(record: HealthRecord) {
        viewModelScope.launch {
            recordDao.delete(record)
        }
    }

    class Factory(private val recordDao: HealthRecordDao) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return HealthRecordViewModel(recordDao) as T
        }
    }
}
