package com.healthtracker.app.model

data class HealthAnalysis(
    val bmi: Float,
    val bmiCategory: String,          // "偏瘦"/"正常"/"超重"/"肥胖"
    val bmiColor: androidx.compose.ui.graphics.Color,
    val bodyFatPercent: Float,          // 体脂率 %
    val bodyFatCategory: String,        // "偏低"/"正常"/"偏高"/"过高"
    val basalMetabolicRate: Float,      // 基础代谢率 kcal
    val idealWeightMin: Float,          // 理想体重范围 kg
    val idealWeightMax: Float,
    val dietAdvice: String,
    val exerciseAdvice: String,
    val bpCategory: String,             // 血压分类
    val bpColor: androidx.compose.ui.graphics.Color,
    val bpAdvice: String
)
