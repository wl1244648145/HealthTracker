package com.healthtracker.app.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.healthtracker.app.data.UserDao
import com.healthtracker.app.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class UserViewModel(private val userDao: UserDao) : ViewModel() {

    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private val _selectedUser = MutableStateFlow<User?>(null)
    val selectedUser: StateFlow<User?> = _selectedUser.asStateFlow()

    init {
        viewModelScope.launch {
            userDao.getAllUsers().collect { list ->
                _users.value = list
            }
        }
    }

    fun selectUser(userId: Long) {
        viewModelScope.launch {
            _selectedUser.value = userDao.getUserById(userId)
        }
    }

    fun addUser(name: String, gender: String, age: Int, heightCm: Float) {
        viewModelScope.launch {
            userDao.insert(User(name = name, gender = gender, age = age, heightCm = heightCm))
        }
    }

    fun updateUser(user: User) {
        viewModelScope.launch {
            userDao.update(user)
            if (_selectedUser.value?.id == user.id) {
                _selectedUser.value = user
            }
        }
    }

    fun deleteUser(user: User) {
        viewModelScope.launch {
            userDao.delete(user)
            if (_selectedUser.value?.id == user.id) {
                _selectedUser.value = null
            }
        }
    }

    class Factory(private val userDao: UserDao) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return UserViewModel(userDao) as T
        }
    }
}
