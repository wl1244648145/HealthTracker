package com.healthtracker.app

import android.app.Application
import com.healthtracker.app.data.AppDatabase

class HealthTrackerApp : Application() {
    val database: AppDatabase by lazy { AppDatabase.getInstance(this) }
}
