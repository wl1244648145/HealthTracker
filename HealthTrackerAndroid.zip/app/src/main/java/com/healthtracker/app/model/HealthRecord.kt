package com.healthtracker.app.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "health_records",
    foreignKeys = [
        ForeignKey(
            entity = User::class,
            parentColumns = ["id"],
            childColumns = ["userId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("userId"), Index("date")]
)
data class HealthRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: Long,
    val date: Long,           // 时间戳(当天零点)
    val weightKg: Float,      // 体重 kg
    val systolic: Int,        // 收缩压 mmHg
    val diastolic: Int,       // 舒张压 mmHg
    val heartRate: Int = 0,   // 心率 bpm (可选)
    val note: String = "",    // 备注
    val createdAt: Long = System.currentTimeMillis()
)
