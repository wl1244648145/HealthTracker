package com.healthtracker.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.healthtracker.app.ui.screen.AddRecordScreen
import com.healthtracker.app.ui.screen.AnalysisScreen
import com.healthtracker.app.ui.screen.UserDetailScreen
import com.healthtracker.app.ui.screen.UserListScreen
import com.healthtracker.app.ui.theme.HealthTrackerTheme
import com.healthtracker.app.viewmodel.HealthRecordViewModel
import com.healthtracker.app.viewmodel.UserViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val db = (application as HealthTrackerApp).database

        setContent {
            HealthTrackerTheme {
                App(db.userDao(), db.healthRecordDao())
            }
        }
    }
}

@Composable
fun App(userDao: com.healthtracker.app.data.UserDao, recordDao: com.healthtracker.app.data.HealthRecordDao) {
    val userViewModel: UserViewModel = viewModel(factory = UserViewModel.Factory(userDao))
    val recordViewModel: HealthRecordViewModel = viewModel(factory = HealthRecordViewModel.Factory(recordDao))

    val users by userViewModel.users.collectAsState()
    val selectedUser by userViewModel.selectedUser.collectAsState()

    if (users.isEmpty()) {
        UserListScreen(
            users = emptyList(),
            selectedUser = null,
            onSelectUser = {},
            onAddUser = { name, gender, age, height -> userViewModel.addUser(name, gender, age, height) },
            onDeleteUser = {}
        )
        return
    }

    if (selectedUser == null) {
        UserListScreen(
            users = users,
            selectedUser = null,
            onSelectUser = { userViewModel.selectUser(it) },
            onAddUser = { name, gender, age, height -> userViewModel.addUser(name, gender, age, height) },
            onDeleteUser = { userViewModel.deleteUser(it) }
        )
        return
    }

    selectedUser?.let { user ->
        var currentTab by remember { mutableStateOf(0) }
        val tabs = listOf("历史记录", "添加记录", "健康分析")
        val icons = listOf(Icons.Default.History, Icons.Default.Add, Icons.Default.TrendingUp)

        LaunchedEffect(user.id) {
            recordViewModel.loadRecords(user.id)
        }

        Scaffold(
            bottomBar = {
                NavigationBar {
                    tabs.forEachIndexed { index, title ->
                        NavigationBarItem(
                            selected = currentTab == index,
                            onClick = { currentTab = index },
                            label = { Text(title) },
                            icon = { Icon(icons[index], contentDescription = title) }
                        )
                    }
                }
            }
        ) { padding ->
            when (currentTab) {
                0 -> UserDetailScreen(
                    user = user,
                    recordViewModel = recordViewModel,
                    modifier = Modifier.padding(padding)
                )
                1 -> AddRecordScreen(
                    user = user,
                    onAddRecord = { date, weight, sys, dia, hr, note ->
                        recordViewModel.addRecord(user.id, date, weight, sys, dia, hr, note)
                        currentTab = 0
                    },
                    modifier = Modifier.padding(padding)
                )
                2 -> AnalysisScreen(
                    user = user,
                    recordViewModel = recordViewModel,
                    modifier = Modifier.padding(padding)
                )
            }
        }
    }
}
