package com.healthtracker.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.healthtracker.app.model.HealthRecord
import kotlinx.coroutines.flow.Flow

@Dao
interface HealthRecordDao {
    @Query("SELECT * FROM health_records WHERE userId = :userId ORDER BY date DESC")
    fun getRecordsByUser(userId: Long): Flow<List<HealthRecord>>

    @Query("SELECT * FROM health_records WHERE userId = :userId AND date >= :startDate AND date <= :endDate ORDER BY date ASC")
    fun getRecordsByDateRange(userId: Long, startDate: Long, endDate: Long): Flow<List<HealthRecord>>

    @Query("SELECT * FROM health_records WHERE id = :id")
    suspend fun getRecordById(id: Long): HealthRecord?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(record: HealthRecord): Long

    @Update
    suspend fun update(record: HealthRecord)

    @Delete
    suspend fun delete(record: HealthRecord)

    @Query("DELETE FROM health_records WHERE userId = :userId")
    suspend fun deleteAllForUser(userId: Long)
}
