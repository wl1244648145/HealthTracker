package com.healthtracker.app.ui.screen

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import com.healthtracker.app.model.HealthRecord
import com.healthtracker.app.model.User
import com.healthtracker.app.viewmodel.HealthRecordViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun UserDetailScreen(
    user: User,
    recordViewModel: HealthRecordViewModel,
    modifier: Modifier = Modifier
) {
    val records by recordViewModel.records.collectAsState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "${user.name} 的健康记录",
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (records.isNotEmpty()) {
            Text(
                text = "体重趋势（最近30条）",
                style = MaterialTheme.typography.titleMedium
            )
            Spacer(modifier = Modifier.height(4.dp))
            WeightChart(
                records = records.take(30).reversed(),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
        }

        Text(
            text = "历史记录",
            style = MaterialTheme.typography.titleMedium
        )
        Spacer(modifier = Modifier.height(8.dp))

        if (records.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxWidth().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text("暂无记录，切换到「添加记录」开始记录吧", color = MaterialTheme.colorScheme.outline)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(records) { record ->
                    RecordCard(record = record, onDelete = { recordViewModel.deleteRecord(record) })
                }
            }
        }
    }
}

@Composable
fun RecordCard(record: HealthRecord, onDelete: () -> Unit) {
    val sdf = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = sdf.format(Date(record.date)),
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(text = "体重: ${record.weightKg} kg")
                Text(text = "血压: ${record.systolic}/${record.diastolic} mmHg")
                if (record.heartRate > 0) {
                    Text(text = "心率: ${record.heartRate} bpm")
                }
                if (record.note.isNotBlank()) {
                    Text(
                        text = "备注: ${record.note}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "删除")
            }
        }
    }
}

@Composable
fun WeightChart(records: List<HealthRecord>, modifier: Modifier = Modifier) {
    if (records.size < 2) return
    val textMeasurer = rememberTextMeasurer()
    val lineColor = MaterialTheme.colorScheme.primary
    val axisColor = Color.Gray

    Canvas(modifier = modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
        val weights = records.map { it.weightKg }
        val minW = weights.minOrNull() ?: 0f
        val maxW = weights.maxOrNull() ?: 1f
        val paddingLeft = 40f
        val paddingBottom = 24f
        val chartW = size.width - paddingLeft - 8f
        val chartH = size.height - paddingBottom - 16f
        val range = (maxW - minW).coerceAtLeast(1f)

        // Grid lines and Y labels
        val steps = 4
        for (i in 0..steps) {
            val y = 16f + chartH * (1 - i.toFloat() / steps)
            val wVal = minW + range * (i.toFloat() / steps)
            drawLine(
                color = Color.LightGray,
                start = Offset(paddingLeft, y),
                end = Offset(paddingLeft + chartW, y),
                strokeWidth = 1f
            )
            val textLayout = textMeasurer.measure("%.1f".format(wVal))
            drawText(
                textLayoutResult = textLayout,
                topLeft = Offset(2f, y - textLayout.size.height / 2),
                color = Color.DarkGray
            )
        }

        // Points and path
        val path = Path()
        val points = records.mapIndexed { index, record ->
            val x = paddingLeft + chartW * (index.toFloat() / (records.size - 1).coerceAtLeast(1))
            val y = 16f + chartH * (1 - (record.weightKg - minW) / range)
            Offset(x, y)
        }

        points.forEachIndexed { i, pt ->
            if (i == 0) path.moveTo(pt.x, pt.y) else path.lineTo(pt.x, pt.y)
        }
        drawPath(path = path, color = lineColor, style = Stroke(width = 3f))

        points.forEach { pt ->
            drawCircle(color = lineColor, radius = 4f, center = pt)
        }
    }
}
