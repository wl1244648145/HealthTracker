package com.healthtracker.app.utils

import androidx.compose.ui.graphics.Color
import com.healthtracker.app.model.HealthAnalysis
import com.healthtracker.app.model.HealthRecord
import com.healthtracker.app.model.User
import kotlin.math.pow

object HealthCalculations {

    fun calculateBMI(weightKg: Float, heightCm: Float): Float {
        val heightM = heightCm / 100f
        return if (heightM > 0) weightKg / heightM.pow(2) else 0f
    }

    fun getBMICategory(bmi: Float): Pair<String, Color> {
        return when {
            bmi < 18.5f -> "偏瘦" to Color(0xFF2196F3)
            bmi < 24f -> "正常" to Color(0xFF4CAF50)
            bmi < 28f -> "超重" to Color(0xFFFF9800)
            else -> "肥胖" to Color(0xFFF44336)
        }
    }

    // Deurenberg 公式估算体脂率
    fun calculateBodyFat(
        bmi: Float,
        age: Int,
        gender: String,
        heightCm: Float
    ): Float {
        val isMale = gender == "男"
        val bodyFat = if (isMale) {
            (1.2f * bmi) + (0.23f * age) - (10.8f * 1) - 5.4f
        } else {
            (1.2f * bmi) + (0.23f * age) - (10.8f * 0) - 5.4f
        }
        return bodyFat.coerceIn(2f, 60f)
    }

    fun getBodyFatCategory(bodyFat: Float, gender: String): String {
        val isMale = gender == "男"
        return when {
            isMale -> when {
                bodyFat < 6f -> "过低"
                bodyFat < 14f -> "运动员"
                bodyFat < 18f -> "正常"
                bodyFat < 25f -> "偏高"
                else -> "过高"
            }
            else -> when {
                bodyFat < 14f -> "过低"
                bodyFat < 21f -> "运动员"
                bodyFat < 25f -> "正常"
                bodyFat < 32f -> "偏高"
                else -> "过高"
            }
        }
    }

    // 基础代谢率 (Mifflin-St Jeor)
    fun calculateBMR(weightKg: Float, heightCm: Float, age: Int, gender: String): Float {
        val s = if (gender == "男") 5f else -161f
        return (10f * weightKg) + (6.25f * heightCm) - (5f * age) + s
    }

    fun calculateIdealWeightRange(heightCm: Float): Pair<Float, Float> {
        val heightM = heightCm / 100f
        val min = 18.5f * heightM.pow(2)
        val max = 24f * heightM.pow(2)
        return min to max
    }

    fun getBPCategory(systolic: Int, diastolic: Int): Triple<String, Color, String> {
        return when {
            systolic < 90 || diastolic < 60 ->
                Triple("低血压", Color(0xFF2196F3), "建议适量增加盐分摄入，多喝水，避免突然站立。如症状明显请就医。")
            systolic <= 120 && diastolic <= 80 ->
                Triple("正常", Color(0xFF4CAF50), "血压正常，请继续保持健康的生活方式。")
            systolic <= 139 && diastolic <= 89 ->
                Triple("正常高值", Color(0xFFFFC107), "血压处于正常高值，建议减少盐分摄入，增加运动，定期监测。")
            systolic <= 159 && diastolic <= 99 ->
                Triple("1级高血压", Color(0xFFFF9800), "轻度高血压，建议改善生活方式，必要时咨询医生。")
            systolic <= 179 && diastolic <= 109 ->
                Triple("2级高血压", Color(0xFFF44336), "中度高血压，建议尽快就医，遵医嘱服药。")
            else ->
                Triple("3级高血压", Color(0xFFD32F2F), "重度高血压，请立即就医诊治。")
        }
    }

    fun generateDietAdvice(bmi: Float, bpCategory: String): String {
        val lines = mutableListOf<String>()
        when {
            bmi < 18.5f -> {
                lines.add("增重建议：")
                lines.add("• 增加优质蛋白质摄入（鸡蛋、牛奶、鱼肉、瘦肉）")
                lines.add("• 适当增加碳水化合物（全谷物、糙米、燕麦）")
                lines.add("• 每天可加入少量坚果作为加餐")
                lines.add("• 避免空腹进行高强度运动")
            }
            bmi < 24f -> {
                lines.add("健康饮食建议：")
                lines.add("• 保持均衡饮食，蔬菜、水果、蛋白质、谷物合理搭配")
                lines.add("• 控制油盐摄入，每天盐不超过 5g")
                lines.add("• 多喝水，每天 1500-2000ml")
                lines.add("• 规律饮食，避免暴饮暴食")
            }
            bmi < 28f -> {
                lines.add("减重建议：")
                lines.add("• 控制总热量，晚餐减少主食量")
                lines.add("• 多吃高纤维蔬菜（芹菜、西兰花、菠菜）")
                lines.add("• 用粗粮代替部分精米白面")
                lines.add("• 减少高糖饮料和零食")
            }
            else -> {
                lines.add("减重建议（体重超标）：")
                lines.add("• 严格控制热量摄入，避免油炸、甜食")
                lines.add("• 增加蔬菜比例，每餐蔬菜占一半")
                lines.add("• 选择低升糖指数食物（燕麦、红薯、糙米）")
                lines.add("• 多喝水，饭前喝一杯水有助控制食欲")
            }
        }
        if (bpCategory.contains("高血压") || bpCategory.contains("正常高值")) {
            lines.add("")
            lines.add("血压管理饮食建议：")
            lines.add("• 严格限盐，每天不超过 5g")
            lines.add("• 多吃富含钾的食物（香蕉、土豆、菠菜）")
            lines.add("• 减少加工食品和腌制品")
        }
        return lines.joinToString("\n")
    }

    fun generateExerciseAdvice(bmi: Float, bpCategory: String): String {
        val lines = mutableListOf<String>()
        when {
            bmi < 18.5f -> {
                lines.add("• 以力量训练为主，增加肌肉量")
                lines.add("• 避免过量有氧运动消耗过多热量")
                lines.add("• 每周3-4次训练，每次30-45分钟")
            }
            bmi < 24f -> {
                lines.add("• 保持有氧运动习惯（快走、慢跑、游泳）")
                lines.add("• 每周150分钟中等强度运动")
                lines.add("• 结合力量训练，每周2次")
                lines.add("• 日常多走路，减少久坐")
            }
            else -> {
                lines.add("• 低冲击有氧运动（快走、游泳、骑车）")
                lines.add("• 循序渐进，每周增加运动时间不超过10%")
                lines.add("• 避免对膝盖冲击大的运动（跳跃、冲刺跑）")
                lines.add("• 运动后注意拉伸放松")
            }
        }
        if (bpCategory.contains("高血压")) {
            lines.add("")
            lines.add("高血压患者运动注意：")
            lines.add("• 避免憋气发力（如举重）")
            lines.add("• 运动前后监测血压")
            lines.add("• 出现头晕、胸闷立即停止")
        }
        return lines.joinToString("\n")
    }

    fun buildAnalysis(user: User, latestRecord: HealthRecord?): HealthAnalysis {
        val weight = latestRecord?.weightKg ?: 60f
        val bmi = calculateBMI(weight, user.heightCm)
        val (bmiCat, bmiColor) = getBMICategory(bmi)
        val bodyFat = calculateBodyFat(bmi, user.age, user.gender, user.heightCm)
        val bodyFatCat = getBodyFatCategory(bodyFat, user.gender)
        val bmr = calculateBMR(weight, user.heightCm, user.age, user.gender)
        val (idealMin, idealMax) = calculateIdealWeightRange(user.heightCm)
        val sys = latestRecord?.systolic ?: 120
        val dia = latestRecord?.diastolic ?: 80
        val (bpCat, bpColor, bpAdvice) = getBPCategory(sys, dia)
        val diet = generateDietAdvice(bmi, bpCat)
        val exercise = generateExerciseAdvice(bmi, bpCat)

        return HealthAnalysis(
            bmi = bmi,
            bmiCategory = bmiCat,
            bmiColor = bmiColor,
            bodyFatPercent = bodyFat,
            bodyFatCategory = bodyFatCat,
            basalMetabolicRate = bmr,
            idealWeightMin = idealMin,
            idealWeightMax = idealMax,
            dietAdvice = diet,
            exerciseAdvice = exercise,
            bpCategory = bpCat,
            bpColor = bpColor,
            bpAdvice = bpAdvice
        )
    }
}
